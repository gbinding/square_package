squared <- function(x){
  x^2
}